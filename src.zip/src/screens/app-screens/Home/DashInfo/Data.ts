const DashInfoData = [
    {
        ExperimentCount: '3',
        FieldCount: '4',
        RecordCount: '25',
      },
]
export {DashInfoData}