import { StyleSheet } from "react-native";

const HeaderStyles = StyleSheet.create({
    main:{
        marginTop:-15
    },
    container: {
        justifyContent: 'space-between',
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        height:80,
      },
      // profileContainer: {
      //   height: 50,
      //   width: 50,
      //   borderRadius: 50,
        
      // },


})
export default HeaderStyles