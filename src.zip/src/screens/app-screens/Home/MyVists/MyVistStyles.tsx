import { StyleSheet } from "react-native";

const MyvistStyle = StyleSheet.create({
    upcomingVisitsContainer: {
        gap: 10,
    },
    upcomingVisitsTitle: {
        fontSize: 15,
        color: '#161616',
        fontWeight: '500',
    },


})
export default MyvistStyle;