import RNFONTS from './inter';

export const FONTS = RNFONTS.FONTS;
