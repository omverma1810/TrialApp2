export default {
  FONTS: {
    REGULAR: 'Montserrat-Regular',
    MEDIUM: 'Montserrat-Medium',
    SEMI_BOLD: 'Montserrat-SemiBold',
    BOLD: 'Montserrat-Bold',
  },
};
