export default {
  FONTS: {
    REGULAR: 'Inter-Regular',
    MEDIUM: 'Inter-Medium',
    SEMI_BOLD: 'Inter-SemiBold',
    BOLD: 'Inter-Bold',
  },
};
