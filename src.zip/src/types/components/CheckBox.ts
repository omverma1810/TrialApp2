export type CheckBoxType = {
  value: boolean;
  onChange: (value: boolean) => void;
};
