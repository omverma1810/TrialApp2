export type RadioButtonType = {
  value: boolean;
  onChange: (value: boolean) => void;
};
