export type SwitchType = {
  value: boolean;
  onChange: (value: boolean) => void;
};
