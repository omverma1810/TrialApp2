export type OverlayLoaderTypes = {
  isModalVisible: boolean;
};
