import {ReactNode} from 'react';
import {TextProps} from 'react-native';

export type TextTypes = {
  children?: ReactNode;
} & TextProps;
