import {ActivityIndicatorProps} from 'react-native';

export type LoaderTypes = {} & ActivityIndicatorProps;
