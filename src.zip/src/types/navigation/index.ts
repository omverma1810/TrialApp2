export type RootStackParamList = {
  AuthRoutes: undefined;
  AppRoutes: undefined;
  Splash : undefined;
};
