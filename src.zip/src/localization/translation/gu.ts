export default {
  COMMON: {
    LBL_WELCOME: 'રીએક્ટ નેટિવ બોઈલરપ્લેટમાં આપનું સ્વાગત છે',
    LBL_OK: 'બરાબર',
    LBL_CANCEL: 'રદ કરો',
    LBL_LOADING: 'લોડ કરી રહ્યું છે',
  },
};
