export const APP_LOGO = require('./app-logo.png');
export const FARM_BG = require('./farm-bg.png');
